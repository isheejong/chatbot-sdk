webpackJsonp([185],{750:function(e,t,d){"use strict";function u(e,t,d,u){return r[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=u;var r={lastWeek:"[letzten] dddd [um] LT",yesterday:"[gestern um] LT",today:"[heute um] LT",tomorrow:"[morgen um] LT",nextWeek:"dddd [um] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=6ece9f269a8772d14358.js.map
