webpackJsonp([56],{880:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var t=Y(194),L=function(e){return e&&e.__esModule?e:{default:e}}(t),d=(0,L.default)({LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY р.",LLL:"D MMMM YYYY р., HH:mm",LLLL:"dddd, D MMMM YYYY р., HH:mm"});M.default=d,e.exports=M.default}});
//# sourceMappingURL=0afebbc7d60653de7d50.js.map
