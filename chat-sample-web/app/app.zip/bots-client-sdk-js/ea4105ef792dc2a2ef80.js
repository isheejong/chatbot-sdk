webpackJsonp([70],{866:function(e,t,d){"use strict";function r(e,t,d,r){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=r;var o={lastWeek:"[förra] dddd[en kl.] LT",yesterday:"[igår kl.] LT",today:"[idag kl.] LT",tomorrow:"[imorgon kl.] LT",nextWeek:"dddd [kl.] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=ea4105ef792dc2a2ef80.js.map
